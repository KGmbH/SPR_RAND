// In this file you can specify the trial data for your experiment


const trial_info = {
    tryout: [// trial items - dienen nur der Übung
	{
	    QUD: "<img src='images/bus_1f68c.png', height=0px>",
	 sentence: "Da | fährt | der | Anschlusszug | schon | weg. | Ali | muss | irgendwie | mit | dem | <img src = 'images/bus_1f68c.png', height=40px> | nach | Hause | kommen.",
	question: "Ist Ali auf dem Weg nach Hause?",
        option1: "Ja",
	option2: "Nein",
	correct_answer: "Ja",
	itemname: "training_zug",
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    },
	{
   QUD: "<img src='images/face-with-rolling-eyes_1f644.png', height=0px>",
	 sentence: "Das | Meeting | war | langweilig | wie | immer. | Samia | schickt | gleich | noch | ein | <img src = 'images/face-with-rolling-eyes_1f644.png', height=40px> | per | SMS.",
	question: "War das Meeting spannend?",
        option1: "Ja",
        option2: "Nein",
	correct_answer: "Nein",
	itemname: "training_meeting",
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
	    ],
    spr: [{
// Item 1-8 von 15
   QUD: "<img src='images/EISice-cream_1f368.png', height=0px><img src='images/EISsnowflake_2744.png', height=0px>",
	 sentence: "Wir | essen | gleich | noch | den | Nachtisch. | Mara | sucht | im | Moment | das | ".concat(emojis.Nachtisch[coin]," | mit | den | Schokostückchen."),
	question: "Sucht Mara cremiges Speiseeis?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
	itemname: "nachtisch",
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/EISice-cream_1f368.png', height=0px><img src='images/EISsnowflake_2744.png', height=0px>",
	 sentence: "Draußen | sind | schon | unter | null | Grad. | Mara | kratzt | im | Moment | das | ".concat(emojis.Grad[coin]," | von | der | Frontscheibe."),
        question: "Putzt Mara einen Nachtisch von ihrem Auto?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
	itemname: "grad",
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/RADbicycle_1f6b2.png', height=0px><img src='images/RADperson-doing-cartwheel_1f938.png', height=0px>",
	 sentence: "Die | Hausbewohner | machen | draußen | zusammen | Akrobatikübungen. | Emma | lernt | wie | selbstverständlich | das | ".concat(emojis.Akrobatik[coin]," | von | der | Nachbarin."),
        question: "Nutzt Emma gerade ein Fahrrad?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'akrobatik',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/RADbicycle_1f6b2.png', height=0px><img src='images/RADperson-doing-cartwheel_1f938.png', height=0px>",
	 sentence: "Die | Hausbewohner | machen | draußen | ein | Wettrennen. | Emma | nimmt | wie | selbstverständlich | das | ".concat(emojis.Wettrennen[coin]," | von | der | Nachbarin."),
        question: "Nutzt Emma das Fahrrad von ihrer Nachbarin?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'wettrennen',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/KARTEcredit-card_1f4b3.png', height=0px><img src='images/KARTEworld-map_1f5fa.png', height=0px>",
	 sentence: "Die | Straße | ist | vielleicht | gar | nicht | eingezeichnet. | Luka | betrachtet | sehr | sorgfältig | die | ".concat(emojis.Stadt[coin]," | von | dem | Reiseziel."),
        question: "Schaut Luka auf eine Landkarte?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'stadt',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/KARTEcredit-card_1f4b3.png', height=0px><img src='images/KARTEworld-map_1f5fa.png', height=0px>",
	 sentence: "Es | gab | ein | Problem | am | Bankschalter. | Luka | betrachtet | sehr | sorgfältig | die | ".concat(emojis.Bank[coin]," | von | der | Kundin."),
        question: "Schaut Luka auf eine Landkarte?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'bank',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/MAUSmouse_1f401.png', height=0px><img src='images/MAUSthree-button-mouse_1f5b1.png', height=0px>",
	 sentence: "Die | Nagetiere | der | Zoohandlung | sind | außergewöhnlich. | Tina | kauft | sicher | bald | die | ".concat(emojis.Nagetier[coin]," | mit | den | Streifen."),
        question: "Interessiert sich Tina für ein Nagetier?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'nagetier',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/MAUSmouse_1f401.png', height=0px><img src='images/MAUSthree-button-mouse_1f5b1.png', height=0px>",
	 sentence: "Das | PC-Zubehör | des | Elektroladens | ist | außergewöhnlich. | Tina | kauft | sicher | bald | die | ".concat(emojis.Computer[coin]," | mit | den | Streifen."),
        question: "Interessiert sich Tina für ein Nagetier?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'computer',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/SCHLOSSeuropean-castle_1f3f0.png', height=0px><img src='images/SCHLOSSlock_1f512.png', height=0px>",
	 sentence: "Die | Tür | hat | sie | schon | geschlossen. | Lisa | hängt | gleich | noch | das | ".concat(emojis.Tür[coin]," | an | den | Riegel."),
        question: "Befestigt Lisa ein Vorhängeschloss?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'tür',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/SCHLOSSeuropean-castle_1f3f0.png', height=0px><img src='images/SCHLOSSlock_1f512.png', height=0px>",
	 sentence: "Das | Partythema | ist | Ritter | und | Prinzessinnen. | Lisa | malt | gleich | noch | das | ".concat(emojis.Prinzessin[coin]," | auf | die | Grußkarte."),
        question: "Malt Lisa ein Türschloss?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'prinzessin',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/HAHNchicken_1f414.png', height=0px><img src='images/HAHNpotable-water-symbol_1f6b0.png', height=0px>",
	 sentence: "Die | Hühner | sind | schon | alle | im | Stall. | Alex | setzt | später | noch | den | ".concat(emojis.Stall[coin]," | in | das | Gehege."),
        question: "Bringt Alex ein Tier in seinen Käfig?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'stall',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/HAHNchicken_1f414.png', height=0px><img src='images/HAHNpotable-water-symbol_1f6b0.png', height=0px>",
	 sentence: "Der | Klempner | hat | einige | Aufgaben | vergessen. | Alex | repariert | später | noch | den | ".concat(emojis.Klempner[coin]," | an | der | Badewanne."),
        question: "Hat Alex mit einem männlichen Tier zu tun?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'klempner',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/BLATTleaf-fluttering-in-wind_1f343.png', height=0px><img src='images/PAPIERpage-facing-up_1f4c4.png', height=0px>",
	 sentence: "Seine | Tochter | hat | ein | Bild | gemalt. | Bodo | heftet | im | Augenblick | das | ".concat(emojis.Papier[coin]," | an | den | Kühlschrank."),
        question: "Heftet Bodo ein Laubblatt an den Kühlschrank?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'papier',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/BLATTleaf-fluttering-in-wind_1f343.png', height=0px><img src='images/PAPIERpage-facing-up_1f4c4.png', height=0px>",
	 sentence: "Er | sammelt | dieses | Jahr | begeistert | Herbstlaub. | Bodo | gefällt | im | Augenblick | das | ".concat(emojis.Blatt[coin]," | mit | dem | Farbverlauf."),
        question: "Gefällt Bodo ein Laubblatt?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'blatt',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/BIRNEelectric-light-bulb_1f4a1.png', height=0px><img src='images/BIRNEpear_1f350.png', height=0px>",
	 sentence: "Der | Obstsalat | ist | noch | nicht | fertig. | Jana | schneidet | gerade | bestimmt | die | ".concat(emojis.Obstsalat[coin]," | in | der | Küche."),
        question: "Bearbeitet Jana eine Glühbirne?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'obstsalat',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
	{
      QUD: "<img src='images/BULLEox_1f402.png', height=0px><img src='images/POLpolice-officer_1f46e.png', height=0px>",
	sentence: "Die | Kühe | haben | ihm | sehr | gefallen. | Timo | bewundert | sogar | schon | den |  ".concat(emojis.Kuh[coin]," | auf | der | Weide."),
        question: "Bewundert Timo einen Polizisten?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'kuh',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/ZOLLcustoms_1f6c3.png', height=0px><img src='images/ZOLLstraight-ruler_1f4cf.png', height=0px>",
	sentence: "Am | Flughafen | kontrollieren | sie | wegen | Schmuggel. | Nico | durchläuft | gerade | noch | den | ".concat(emojis.Schmuggel[coin]," | nach | dem | Gepäckband."),
        question: "Durchläuft Nico eine Zollkontrolle?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'schmuggel',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/ZOLLcustoms_1f6c3.png', height=0px><img src='images/ZOLLstraight-ruler_1f4cf.png', height=0px>",
	sentence: "Die | Längenumrechnung | in | Amerika | ist | schwierig. | Nico | addiert | gerade | noch | den | ".concat(emojis.Längenumrechnung[coin]," | für | den | Bildschirm."),
        question: "Fügt Nico eine Zollkontrolle hinzu?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'längenumrechnung',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/DACHSbadger_1f9a1.png', height=0px><img src='images/DAXchart-with-upwards-trend_1f4c8.png', height=0px>",
	sentence: "Die | Aktien | in | Deutschland | fallen | wieder. | Caro | analysiert | sehr | motiviert | den  | ".concat(emojis.Aktien[coin]," | für | die | Firma."),
        question: "Untersucht Caro Aktien?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'aktien',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/DACHSbadger_1f9a1.png', height=0px><img src='images/DAXchart-with-upwards-trend_1f4c8.png', height=0px>",
	sentence: "Ihr | Projekt | dreht | sich | um | Waldtiere. | Caro | untersucht | sehr | motiviert | den | ".concat(emojis.Waldtier[coin]," | für | die | Abschlussarbeit."),
        question: "Beschäftigt sich Caro mit Aktien?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'waldtier',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/WAHLballot-box-with-ballot_1f5f3.png', height=0px><img src='images/WALspouting-whale_1f433.png', height=0px>",
	sentence: "Sie | betreut | die | Meeressäuger | im | Aquarium. | Sara | versorgt | heute | noch | den | ".concat(emojis.Meeressäuger[coin]," | in | dem | Panoramabecken."),
        question: "Betreut Sara eine politische Wahl?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'meeressäuger',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/WAHLballot-box-with-ballot_1f5f3.png', height=0px><img src='images/WALspouting-whale_1f433.png', height=0px>",
	sentence: "Sie | findet | politisches | Engagement | sehr | wichtig. | Sara | organisiert | heute | noch | die | ".concat(emojis.Politik[coin]," | für | den | Bürgermeister."),
        question: "Leitet Sara eine Bürgermeisterwahl?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'politik',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/WEINcrying-face_1f622.png', height=0px><img src='images/WEINwine-glass_1f377.png', height=0px>",
	sentence: "Alkohol | trinkt | sie | nur | mit | Stil. | Emma | genießt | inzwischen | schon | den | ".concat(emojis.Alkohol[coin]," | aus | der | Bretagne."),
        question: "Trinkt Emma französischen Wein?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'alkohol',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/WEINcrying-face_1f622.png', height=0px><img src='images/WEINwine-glass_1f377.png', height=0px>",
	sentence: "Tränen | sind | bei | ihr | quasi | vorprogrammiert. | Emma | instrumentalisiert | inzwischen | schon | das | ".concat(emojis.Tränen[coin]," | bei | den | Eltern."),
        question: "Weint Emma selten?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'tränen',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/BAUERblack-chess-pawn_265f.png', height=0px><img src='images/BAUERmale-farmer_1f468-200d-1f33e.png', height=0px>",
	sentence: "Eine | der | Schachfiguren | ist | gerade | runtergefallen. | Leon | repariert | sehr | eilig | den | ".concat(emojis.Schach[coin]," | mit | dem | Sekundenkleber."),
        question: "Klebt Leon eine Figur aus einem Schachspiel?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'schach',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/BAUERblack-chess-pawn_265f.png', height=0px><img src='images/BAUERmale-farmer_1f468-200d-1f33e.png', height=0px>",
	sentence: "Ein | Schwein | ist | auf | das | Feld | geflohen. | Leon | informiert | sehr | eilig | den | ".concat(emojis.Feld[coin]," | über | das | Problem."),
        question: "Ist Leon mit einer Schachfigur beschäftigt?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'feld',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/STUHLchair_1fa91.png', height=0px><img src='images/STUHLpile-of-poo_1f4a9.png', height=0px>",
	sentence: "Sie | brauchen | eine | Probe | seiner | Ausscheidungen. | Carl | übergibt | morgen | früh | den | ".concat(emojis.Ausscheidung[coin]," | an | die | Pflegerin."),
        question: "Übergibt Carl ein Sitzmöbel an die Pflegerin?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'ausscheidung',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
        QUD: "<img src='images/STUHLchair_1fa91.png', height=0px><img src='images/STUHLpile-of-poo_1f4a9.png', height=0px>",
	sentence: "Er | arbeitet | in | einer | Möbelreparatur. | Carl | leimt | morgen | früh | den | ".concat(emojis.Sitzmöbel[coin]," | für | die | Kundin."),
        question: "Repariert Carl ein Sitzmöbel?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'sitzmöbel',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
      QUD: "<img src='images/BULLEox_1f402.png', height=0px><img src='images/POLpolice-officer_1f46e.png', height=0px>",
	sentence: "Die | Freunde | eskalieren | auf | der | Demo. | Timo | beleidigt | sogar | schon | den | ".concat(emojis.Demo[coin]," | vor | dem | Wasserwerfer."),
        question: "Beleidigt Timo einen Polizisten?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'demo',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/BIRNEelectric-light-bulb_1f4a1.png', height=0px><img src='images/BIRNEpear_1f350.png', height=0px>",
	 sentence: "Die | Beleuchtung | ist | noch | nicht | fertig. | Jana | wechselt | gerade | bestimmt | die | ".concat(emojis.Beleuchtung[coin]," | in | der | Küche."),
        question: "Tauscht Jana eine Glühbirne aus?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'beleuchtung',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
// hier beginnen die Filler
    {
   QUD: "<img src='images/crown.png', height=0px>",
	 sentence: "Sogar | der | Adel | kommt | in | seinen | Salon. | Florian | frisiert | äußerst | vorsichtig | die | <img src = 'images/crown.png', height=40px> | aus | den | Niederlanden.",
        question: "Ist Florian ein Frisör?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_florian',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/laugh.png', height=0px>",
	 sentence: "Sie | hört | einen | lauten | Pups. | Julia | verkneift | sich | gerade | noch | das | <img src = 'images/laugh.png', height=40px> | vor | der | Lehrerin.",
        question: "Lacht Julia laut?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_julia',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/sad.png', height=0px>",
	 sentence: "Der | Käse | und | die | Wurst | sind | aus. | Marlene | kauft | morgen | früh | das | <img src = 'images/sad.png', height=40px> | für | das | Frühstück.",
        question: "Geht Marlene morgen früh einkaufen?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_marlene',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/heart.png', height=0px>",
	 sentence: "Beim | Kardiologen | ist | heute | viel | los. | Bettina | untersucht | als | erstes | das | <img src = 'images/heart.png', height=40px> | von | ihrem | Nachbarn.",
        question: "Ist Bettina Kardiologe?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_bettina',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/person-with-folded-hands_1f64f.png', height=0px>",
	 sentence: "Gott | begleitet | sie | schon | lange. | Juna | faltet | jeden | Morgen | die | <img src = 'images/person-with-folded-hands_1f64f.png', height=40px>  | wenn | sie | betet.",
        question: "Ist Juna eine Atheistin?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_juna',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/black-universal-recycling-symbol_267b.png', height=0px>",
	 sentence: "Die | Büsche | im | Garten | trocknen | aus. | Alina | wässert | sehr | eifrig | den | <img src = 'images/black-universal-recycling-symbol_267b.png', height=40px> | bei | der | Gartenarbeit.",
        question: "Ist Alina im Haus?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_alina',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/multiple-musical-notes_1f3b6.png', height=0px>",
	 sentence: "Die | neuen | Lautsprecher | sind | ein | Graus. | Paulina | hört | abends | oft | die | <img src = 'images/multiple-musical-notes_1f3b6.png', height=40px> | von | ihrer | Mitbewohnerin.",
        question: "Hört Paulina etwas aus den Lautsprechern?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_paulina',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/peanuts_1f95c.png', height=0px>",
	 sentence: "Auf | das | Referat | ist | sie | schlecht | vorbereitet. | Thilda | hält | völlig | nervös | die | <img src = 'images/peanuts_1f95c.png', height=40px> | vor | den | Professoren.",
        question: "Hält Thilda einen Vortrag vor den Mitschülern?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_thilda',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/collision-symbol_1f4a5.png', height=0px>",
	 sentence: "Alle | stehen | voll | auf | den | einen | Schokokuchen. | Romy | bäckt | am | Abend | den | <img src = 'images/collision-symbol_1f4a5.png', height=40px> | für | die | Kinder.",
        question: "Entsteht ein Schokokuchen?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_romy',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/thinking-face_1f914.png', height=0px>",
	 sentence: "Die | Boxen | beinhalten | die | neuen | Produkte. | Maria | beklebt | jeden | Tag | die | <img src = 'images/thinking-face_1f914.png', height=40px> | in | der | Lagerhalle.",
        question: "Arbeitet Maria in einer Schule?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_maria',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/small-airplane_1f6e9.png', height=0px>",
	 sentence: "Seine | Leistung | im | Test | war | überragend. | Elena | lobt | voller | Stolz | den | <img src = 'images/small-airplane_1f6e9.png', height=40px> | aus | der | Klasse.",
        question: "Ist Elena stolz?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_elena',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/negative-squared-latin-capital-letter-p_1f17f.png', height=0px>",
	 sentence: "Das | Rezept | für | die | Soße | ist | langweilig. | Ben | verändert | ohne | Absicht | die | <img src = 'images/negative-squared-latin-capital-letter-p_1f17f.png', height=40px> | für | die | Gäste.",
        question: "Hat Ben etwas gekocht?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_ben',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/female-scientist_1f469-200d-1f52c.png', height=0px>",
	 sentence: "Das | neue | Labor | wurde | überflutet. | Ole | informiert | sofort | die | <img src = 'images/female-scientist_1f469-200d-1f52c.png', height=40px> | über | den | Vorfall.",
        question: "Erzählt Ole jemandem über die Überflutung?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_ole',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/person-climbing_1f9d7.png', height=0px>",
	 sentence: "Die | Kugelschreiber | sind | aus. | Lenny | bestellt | am | Abend | die | <img src = 'images/person-climbing_1f9d7.png', height=40px> | über | die | Webseite.",
        question: "Kauft Lenny Stifte ein?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_lenny',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/goat_1f410.png', height=0px>",
	 sentence: "Auf | der | Arbeit | lästert | sie | ständig. | Lars | feuert | voller | Entsetzen | die | <img src = 'images/goat_1f410.png', height=40px> | für | ihre | Unfreundlichkeit.",
        question: "Entlässt Lars jemanden?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_lars',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/female-cook_1f469-200d-1f373.png', height=0px>",
	 sentence: "Ein | Teil | der | Hausaufgaben | fehlt | noch. | Fritz | schreibt | in | Panik | die | <img src = 'images/female-cook_1f469-200d-1f373.png', height=40px> | an | seinem | PC.",
        question: "Hat Fritz seine Schulaufgaben schon lange fertig?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_fritz',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/fire_1f525.png', height=0px>",
	 sentence: "Er | unterstützt | die | Sportler | beim | Marathonlauf. | Benedikt | winkt | voller | Elan | dem | <img src = 'images/fire_1f525.png', height=40px> | auf | der | Zielgeraden | zu.",
        question: "Guckt Benedikt beim Marathonlauf zu?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_benedikt',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/eyes_1f440.png', height=0px>",
	 sentence: "Wegen | der | neuen | Brille | ist | sie | da. | Isabella | untersucht | sehr | sorgsam | die | <img src = 'images/eyes_1f440.png', height=40px> | von | der | Patientin.",
        question: "Untersucht Isabella die Ohren ihrer Schwester?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_isabella',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/birthday-cake_1f382.png', height=0px>",
	 sentence: "Er | macht | eine | Ausbildung | beim | Juwelier. | Milo | poliert | sehr | präzise | den | <img src = 'images/birthday-cake_1f382.png', height=40px> | mit | dem | Gerät.",
        question: "Ist Milo ein zukünftiger Juwelier?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_milo',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/shield_1f6e1.png', height=0px>",
	 sentence: "Der | Virus | hat | seine | alte | Firewall | überwunden. | Nils | installiert | unter | Zeitdruck | den | <img src = 'images/shield_1f6e1.png', height=40px> | auf | seinem | PC.",
        question: "Spielt Nils ein Computerspiel auf seinem PC?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_nils',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/trophy_1f3c6.png', height=0px>",
	 sentence: "In | der | Bibliothek | sind | alle | still. | Nick | öffnet | ganz | leise | den | <img src = 'images/trophy_1f3c6.png', height=40px> | für | seine | Hausarbeit.",
        question: "Schreibt Nick eine Hausarbeit?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_nick',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: " ",
	 sentence: "Sie | möchte | einen | günstigeren | Stromanbieter | finden. | Lotte | vergleicht | sehr | konzentriert | die | Angebote | auf | der | Webseite.",
        question: "Lässt Lotte sich die ganze Zeit ablenken?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_lotte',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: " ",
	 sentence: "Der | Vorgarten | soll | eingezäunt | werden. | Till | befestigt | wie | vereinbart | den | Zaun | um | die | Beete.",
        question: "Streicht Till den neuen Zaun im Vorgarten?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_till',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: " ",
	 sentence: "Der | Türsteher | ist | ganz | schön | angsteinflößend. | Adrian | verärgert | ganz | unabsichtlich | den | Schrank | vor | dem | Club.",
        question: "Verärgert Adrian den Türsteher mit Absicht?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_adrian',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: " ",
	 sentence: "Die | Blätter | verstopfen | den | Abfluss | vom | Dach. | Marco | säubert | heute | schnell | die | Regenrinne | für | seine | Tochter.",
        question: "Putzt Marco die Regenrinne sehr lange?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_pepe',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: " ",
	 sentence: "Auch | im | Urlaub | benutzt | er | die | öffentlichen | Verkehrsmittel. | Lasse | nimmt | wie | selbstverständlich | den | Bus | zu | der | Unterkunft.",
        question: "Nimmt Lasse auch im Urlaub die öffentlichen Verkehrsmittel?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Ja",
        itemname: 'filler_lasse',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
	 ],
    removed: [//  Filler, die nicht verwendet werden
    {
   QUD: "<img src='images/skateboard.png', height=0px>",
	 sentence: "Er | kommt | gerade | von | der | Skaterampe. | Sebastian | stellt | gleich | noch | das | <img src = 'images/skateboard.png', height=40px> | in | die | Ecke.",
        question: "Hängt Sebastian etwas in die Ecke?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_sebastian',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: "<img src='images/roller-coaster_1f3a2.png', height=0px>",
	 sentence: "Das | Regenwasser | läuft | regelmäßig | über. | Luna | überprüft | jeden | Samstag | die | <img src = 'images/roller-coaster_1f3a2.png', height=40px> | vor | der | Tür.",
        question: "Überprüft Luna täglich etwas?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_luna',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
	{
   QUD: " ",
	sentence: "Die | Journalistin | möchte | ins | ehemalige | Kriegsgebiet. | Thea | bescheinigt | ohne | Zögern | die | Formulare | für | die | Einreise.",
        question: "Benötigt Thea die Formulare als Nachweis für ihren Chef?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_thea',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
,
    {
   QUD: " ",
	 sentence: "Alle | bereiten | sich | auf | die | Debatte | vor. | Anni | sammelt | mit | Nachdruck | die | Punkte | für | ihre | Gruppe.",
        question: "Sammelt Anni Punkte für die Gegner?",
        option1: "Ja",
        option2: "Nein",
        correct_answer: "Nein",
        itemname: 'filler_anni',
        participant_group: coin,
        participant_id: participantID,
        wordPos: 'same',
        underline: 'none'
    }
	]
};


 
       
